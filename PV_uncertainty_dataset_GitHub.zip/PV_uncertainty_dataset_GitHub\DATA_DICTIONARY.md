# Data dictionary

## CSV columns

| Column | Type | Meaning |
|---|---|---|
| `observation_id` | integer | Generated row index, 1-11,680; not a timestamp |
| `pv_series_1` ... `pv_series_5` | double | Values from rows 1-5 of the original `solar_power` matrix |

`pv_timeseries_case_raw.csv` and `pv_timeseries_case_scaled_1p2.csv` contain only columns `pv_series_1` through `pv_series_3`.

## `mat/pv_case_data.mat` variables

| Variable | Size | Meaning |
|---|---:|---|
| `solar_power_all` | 5 × 11,680 | Unmodified source matrix |
| `solar_power_selected_raw` | 3 × 11,680 | Rows 1-3 of the source matrix |
| `solar_power_selected_scaled` | 3 × 11,680 | `1.2 * solar_power_selected_raw` |
| `selected_series` | 1 × 3 | Selected source row indices `[1 2 3]` |
| `scale_factor` | 1 × 1 | Case-study multiplier `1.2` |
| `observation_id` | 11,680 × 1 | Generated sequential observation index |

All recovered values are finite. The source matrix range is 0 to 135. Units are not encoded in the source file and are therefore intentionally left unspecified.
