# Checklist before making the repository public

- [ ] Add the verified name and URL/DOI of the original open power-system data source.
- [ ] Confirm that redistribution is permitted by the source license.
- [ ] Add a `LICENSE` file appropriate for the data and code.
- [ ] Add the physical unit of the PV-output values.
- [ ] Add the sampling interval and timestamp/time-zone information, if available.
- [ ] Replace generic series labels with verified site/plant identifiers, if disclosure is allowed.
- [ ] Add the final paper citation and a `CITATION.cff` file.
- [ ] If the repository is anonymized for peer review, remove identifying metadata until acceptance.

The numeric dataset is ready to upload, but the unchecked provenance and licensing items should be resolved before describing it as a fully documented public dataset.
