%% Prepare the public PV time-series dataset
% Rebuilds the CSV and case-study MAT files from the archived source MAT.

script_file = mfilename('fullpath');
repo_root = fileparts(fileparts(script_file));
source_file = fullfile(repo_root, 'mat', 'pv_power1_original.mat');

assert(isfile(source_file), 'Source MAT file not found: %s', source_file);
source = load(source_file);
assert(isfield(source, 'solar_power'), ...
    'The source MAT file must contain a variable named solar_power.');

solar_power_all = source.solar_power;
assert(isnumeric(solar_power_all) && isreal(solar_power_all), ...
    'solar_power must be a real numeric matrix.');
assert(isequal(size(solar_power_all), [5, 11680]), ...
    'Expected solar_power to have size 5-by-11680.');
assert(all(isfinite(solar_power_all), 'all'), ...
    'solar_power contains NaN or Inf values.');

selected_series = 1:3;
scale_factor = 1.2;
observation_id = (1:size(solar_power_all, 2))';
solar_power_selected_raw = solar_power_all(selected_series, :);
solar_power_selected_scaled = scale_factor * solar_power_selected_raw;

data_dir = fullfile(repo_root, 'data');
if ~isfolder(data_dir)
    mkdir(data_dir);
end

write_pv_csv(fullfile(data_dir, 'pv_timeseries_all.csv'), ...
    observation_id, solar_power_all.');
write_pv_csv(fullfile(data_dir, 'pv_timeseries_case_raw.csv'), ...
    observation_id, solar_power_selected_raw.');
write_pv_csv(fullfile(data_dir, 'pv_timeseries_case_scaled_1p2.csv'), ...
    observation_id, solar_power_selected_scaled.');

save(fullfile(repo_root, 'mat', 'pv_case_data.mat'), ...
    'solar_power_all', 'solar_power_selected_raw', ...
    'solar_power_selected_scaled', 'selected_series', ...
    'scale_factor', 'observation_id', '-v7');

fprintf('Prepared 11,680 observations from five PV series.\n');
fprintf('Case-study input: series 1-3 multiplied by 1.2.\n');

function write_pv_csv(filename, observation_id, values)
    fid = fopen(filename, 'w');
    assert(fid ~= -1, 'Cannot open output file: %s', filename);
    cleanup = onCleanup(@() fclose(fid));

    fprintf(fid, 'observation_id');
    fprintf(fid, ',pv_series_%d', 1:size(values, 2));
    fprintf(fid, '\n');

    for row = 1:size(values, 1)
        fprintf(fid, '%d', observation_id(row));
        fprintf(fid, ',%.17g', values(row, :));
        fprintf(fid, '\n');
    end
end
