# Correlated PV-output time-series data

This repository contains the photovoltaic (PV) output observations used to fit the Gaussian mixture model (GMM) in the accompanying study. The archived source contains five correlated PV series with 11,680 observations per series. The case study uses series 1-3 after multiplying every value by 1.2.

## Files

| File | Shape excluding header/ID | Description |
|---|---:|---|
| `data/pv_timeseries_all.csv` | 11,680 × 5 | All five original PV series |
| `data/pv_timeseries_case_raw.csv` | 11,680 × 3 | Original series 1-3 selected by the case-study code |
| `data/pv_timeseries_case_scaled_1p2.csv` | 11,680 × 3 | Exact GMM-fitting input: selected values multiplied by 1.2 |
| `mat/pv_power1_original.mat` | 5 × 11,680 | Archived original MATLAB variable `solar_power` |
| `mat/pv_case_data.mat` | — | Original, selected, and scaled arrays plus processing metadata |
| `scripts/prepare_dataset.m` | — | Reproducible MATLAB extraction script |
| `checksums.sha256` | — | SHA-256 integrity checks for the distributed data files |

The CSV files are observation-major: one observation per row. `observation_id` is a generated sequential index from 1 to 11,680; it is not a timestamp. The MAT arrays are series-major, consistent with the original code.

## Case-study transformation

The simulation code performs the following operation:

```matlab
load pv_power1.mat
solar_power = solar_power(1:3, :) * 1.2;
```

Therefore, `data/pv_timeseries_case_scaled_1p2.csv` is the exact data matrix supplied to GMM fitting after transposition to an 11,680 × 3 sample matrix.

## Rebuild the derived files

From MATLAB, run:

```matlab
run('scripts/prepare_dataset.m')
```

The script validates the expected dimensions and finite values before replacing the derived CSV and MAT files.

## Important metadata limitation

The recovered source MAT file contains only the numeric matrix `solar_power`. It does not include timestamps, sampling interval, site identifiers, physical units, source URL, or a data license. Consequently, this repository does not infer any of those fields. Add the verified provenance and license before public release; see `PUBLICATION_CHECKLIST.md`.

## Basic loading examples

Python:

```python
import pandas as pd

pv = pd.read_csv("data/pv_timeseries_case_scaled_1p2.csv")
X = pv[["pv_series_1", "pv_series_2", "pv_series_3"]].to_numpy()
```

MATLAB:

```matlab
s = load('mat/pv_case_data.mat');
X = s.solar_power_selected_scaled.';  % 11680-by-3
```

## Citation

When the associated paper has a final bibliographic record, add it here and in a `CITATION.cff` file. Until then, cite the dataset repository URL and the version or commit hash used in your analysis.
