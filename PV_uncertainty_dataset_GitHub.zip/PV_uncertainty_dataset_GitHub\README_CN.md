# 相关光伏出力时序数据

本文件夹整理了论文中用于拟合高斯混合模型（GMM）的光伏出力数据。原始 `solar_power` 矩阵包含 5 条序列，每条 11,680 个观测值；案例程序实际选取第 1–3 条序列，并将所有数值乘以 1.2。

## 数据文件

- `data/pv_timeseries_all.csv`：全部 5 条原始序列。
- `data/pv_timeseries_case_raw.csv`：案例选取的前 3 条原始序列。
- `data/pv_timeseries_case_scaled_1p2.csv`：乘以 1.2 后的案例输入，即用于 GMM 拟合的数据。
- `mat/pv_power1_original.mat`：从学位论文代码目录提取的原始 MAT 文件。
- `mat/pv_case_data.mat`：整理后的 MATLAB 数据，包含全部、筛选后及缩放后三组变量。
- `scripts/prepare_dataset.m`：可重复生成 CSV 和整理后 MAT 文件的脚本。

CSV 中每行对应一个观测，每列对应一条光伏序列。`observation_id` 只是整理时生成的 1–11,680 顺序编号，不代表日期或时间戳。MAT 文件保持原程序采用的“序列 × 观测”方向。

## 已核实的程序对应关系

学位论文代码 `code/main_solve123.m` 和 `code/main_solve14.m` 均执行：

```matlab
load pv_power1.mat
solar_power = solar_power(1:3, :) * 1.2;
```

因此，投稿文字中“5 条序列、每条 11,680 个观测、选取前 3 条并放大 1.2 倍”的描述与程序和本数据包一致。

## 发布前注意

原始 MAT 文件没有携带时间戳、采样间隔、站点名称、物理单位、原始下载地址或许可证信息。本数据包没有猜测这些元数据。公开上传前请根据原始数据来源补充出处和许可，具体见 `PUBLICATION_CHECKLIST.md`。
